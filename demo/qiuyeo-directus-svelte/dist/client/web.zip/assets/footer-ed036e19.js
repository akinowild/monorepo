import{S as t,i as o,s as c,a as d,e as r,d as n,g as v,v as l,o as f}from"./index-941276af.js";function p(e){d(e,"svelte-83p70a",".single-footer-widget.svelte-83p70a a.svelte-83p70a{color:#706f87}")}function g(e){let s;return{c(){s=r("footer"),s.innerHTML=`<div class="container"><div class="row"><div class="col-lg-3 col-md-6 col-sm-6"><div class="single-footer-widget"><h6>About Me</h6> 
            <p>曾经是个摇滚愤青小青年，喜欢唐朝黑豹超载一大帮子，然后子曰主唱让我觉得这个名字不错。然后就用了。</p></div></div> 
        <div class="col-lg-4 col-md-6 col-sm-6"><div class="single-footer-widget svelte-83p70a"><h6>备案号</h6> 
            <p><a target="_blank" rel="noopener" href="http://beian.miit.gov.cn/" class="svelte-83p70a">苏ICP备2021047286号-1</a></p></div></div> 
        <div class="col-lg-3 col-md-6 col-sm-6"><div class="single-footer-widget mail-chimp"><h6 class="mb-20">Instragram Feed</h6> 
            <ul class="instafeed d-flex flex-wrap"></ul></div></div> 
        <div class="col-lg-2 col-md-6 col-sm-6"><div class="single-footer-widget svelte-83p70a"><h6>Follow Us</h6> 
            <p>Let us be social</p> 
            <div class="footer-social d-flex align-items-center"><a href="" class="svelte-83p70a"><i class="fa fa-facebook"></i></a> 
              <a href="" class="svelte-83p70a"><i class="fa fa-twitter"></i></a> 
              <a href="" class="svelte-83p70a"><i class="fa fa-dribbble"></i></a> 
              <a href="" class="svelte-83p70a"><i class="fa fa-behance"></i></a></div></div></div></div></div>`,n(s,"class","footer-area section-gap")},m(a,i){v(a,s,i)},p:l,i:l,o:l,d(a){a&&f(s)}}}class h extends t{constructor(s){super(),o(this,s,null,g,c,{},p)}}export{h as F};
