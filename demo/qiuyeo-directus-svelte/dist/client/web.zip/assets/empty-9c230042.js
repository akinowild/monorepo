const e="/assets/empty-44c9bf8b.jpg";export{e};
