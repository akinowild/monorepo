import{S as n,i as t,s as r,a as p,e as c,d as g,g as o,v as i,o as d}from"./index-941276af.js";function f(e){p(e,"svelte-5viwvd",".blog-pagination.svelte-5viwvd{grid-column:1 /3}")}function v(e){let a;return{c(){a=c("nav"),a.innerHTML=`<ul class="pagination"><li class="page-item"><a href="" class="page-link" aria-label="Previous"><span aria-hidden="true"><span class="ti-arrow-left"></span></span></a></li> 
        <li class="page-item"><a href="" class="page-link">01</a></li> 
        <li class="page-item active"><a href="" class="page-link">02</a></li> 
        <li class="page-item"><a href="" class="page-link">03</a></li> 
        <li class="page-item"><a href="" class="page-link">04</a></li> 
        <li class="page-item"><a href="" class="page-link">09</a></li> 
        <li class="page-item"><a href="" class="page-link" aria-label="Next"><span aria-hidden="true"><span class="ti-arrow-right"></span></span></a></li></ul>`,g(a,"class","blog-pagination justify-content-center d-flex svelte-5viwvd")},m(s,l){o(s,a,l)},p:i,i,o:i,d(s){s&&d(a)}}}class u extends n{constructor(a){super(),t(this,a,null,v,r,{},f)}}export{u as P};
