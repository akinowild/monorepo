const log = (text) =>{
    console.log(text)
}

export default log;