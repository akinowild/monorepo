import log from "./log";

export {log}